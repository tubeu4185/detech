<?php

$ranges = array(285212672 => array(352321535, 'US'));
