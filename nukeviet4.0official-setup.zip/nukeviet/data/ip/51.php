<?php

$ranges = array(855638016 => array(872415231, 'GB'));
