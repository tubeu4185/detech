<?php

$ranges = array(920649728 => array(956301311, 'US'));
