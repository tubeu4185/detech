<?php

$ranges = array(3992977408 => array(4261412863, 'ZZ'));
