<?php

$ranges = array(738197504 => array(755105791, 'US'));
