<?php

$ranges = array(3808428032 => array(4076863487, 'ZZ'));
