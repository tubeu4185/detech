<?php

$ranges = array(805306368 => array(822083583, 'US'));
