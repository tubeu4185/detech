<?php

$ranges = array(2231369728 => array(2248146943, 'JP'));
