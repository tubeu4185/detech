<?php

$ranges = array(3825205248 => array(4093640703, 'ZZ'));
