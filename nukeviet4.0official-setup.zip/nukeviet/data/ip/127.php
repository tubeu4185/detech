<?php

$ranges = array(2130706432 => array(2130771967, 'ZZ'), 2130706432 => array(2147483647, 'ZZ'));
