<?php

$ranges = array(469762048 => array(503316479, 'US'));
