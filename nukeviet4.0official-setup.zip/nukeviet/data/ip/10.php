<?php

$ranges = array(167772160 => array(184549375, 'ZZ'));
