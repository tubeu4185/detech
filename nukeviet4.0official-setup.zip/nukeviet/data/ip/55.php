<?php

$ranges = array(921698304 => array(939524095, 'US'));
