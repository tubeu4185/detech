<?php

$ranges = array(436207616 => array(452984831, 'US'));
