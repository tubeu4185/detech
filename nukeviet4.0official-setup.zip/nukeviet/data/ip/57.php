<?php

$ranges = array(956301312 => array(973078527, 'FR'));
