<?php

$ranges = array(872415232 => array(889192447, 'US'));
