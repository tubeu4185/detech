<?php

$ranges = array(889192448 => array(905969663, 'DE'));
