<?php

$ranges = array(2113929216 => array(2130706431, 'JP'));
