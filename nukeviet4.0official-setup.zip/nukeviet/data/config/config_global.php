<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2015 VINADES.,JSC. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Thu, 30 Jul 2015 10:08:28 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );