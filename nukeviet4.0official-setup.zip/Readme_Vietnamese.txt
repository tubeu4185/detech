﻿Hướng dẫn cài đặt NukeViet 4.0 Official:

1. Giải nén file tải về.
2. Upload toàn bộ các file và thư mục con trong thư mục "nukeviet" lên thư mục gốc của website.
3. Truy cập Website để tiến hành cài đặt.

Yêu cầu cài đặt:
- Hệ điều hành:  Unix (Linux, Ubuntu, Fedora...) hoặc Windows
- PHP: PHP 5.5
- MySQL:  MySQL 5.5

Mọi thắc mắc và yêu cầu trợ giúp vui lòng truy cập website: https://nukeviet.vn 
hoặc tham gia diễn đàn https://forum.nukeviet.vn
     gia nhập nhóm facebook: http://fb.com/groups/nukeviet/