﻿Installation instructions NukeViet 4.0 Official:

1. Unzip the downloaded file.
2. Upload all files and subdirectories in the directory "nukeviet" to the root directory of the website.
3. Access the website by internet browser to install.

Requirements for NukeViet 4.0 Official:
- OS: Unix (Linux, Ubuntu, Fedora ...) or Windows
- PHP: PHP 5.5
- MySQL: MySQL 5.5

All questions and request assistance please visit website: https://nukeviet.vn
or join forum: https://nukeviet.vn/vi/forum/
        group facebook: http://fb.com/groups/nukeviet/